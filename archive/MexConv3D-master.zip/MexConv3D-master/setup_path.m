dir_this = fileparts( mfilename('fullpath') );
addpath( dir_this );
addpath( fullfile(dir_this, 'util') );