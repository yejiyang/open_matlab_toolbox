`conv3d_*.m`: examples for fprop() and bprop() of 3d convolution

`maxpool3d_*.m`: examples for fprop() and bprop() of 3d max pooling

`conv3d_vs_matconvnet_*.m`: show how to do 2d convolution with 3d convolution and compare the results with vlfeat/matconvnet.
Just for illustration, always use 2d convolution if the problem is intrinsically 2d!
