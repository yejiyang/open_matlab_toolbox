An example for simple net of the vlfeat/matconvnet fashion.

Based on code of Sushma Rudra.