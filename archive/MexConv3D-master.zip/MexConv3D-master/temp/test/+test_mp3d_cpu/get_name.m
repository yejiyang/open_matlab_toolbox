function nm = get_name()
%GET_NAME Summary of this function goes here
%   Detailed explanation goes here
  nm = 'maxpool3d_cpu';
  
end

