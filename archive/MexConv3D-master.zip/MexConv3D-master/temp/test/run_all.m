%%
test_mp3d_cpu.run_batch();
test_mp3d_cpu.run_timing();