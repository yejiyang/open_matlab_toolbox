%% data
sz = [64,64,64, 10,9];
x = gpuArray.rand(sz, 'single');
%% fprop
temp2(x)