%%
convmat = gpuArray.rand(1024, 500, 'single');
F = gpuArray.rand(500, 16, 'single');


temp3(convmat,F);