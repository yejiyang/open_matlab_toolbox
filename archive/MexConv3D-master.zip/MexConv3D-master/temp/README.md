A sandbox. 

All files in this folder will be removed.
