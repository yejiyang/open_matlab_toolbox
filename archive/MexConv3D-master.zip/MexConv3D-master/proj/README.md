Just for debugging and viewing the source files in IDE. 

Don't build the project with this, use the `make_all.m` in root directory instead!