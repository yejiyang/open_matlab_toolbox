Unist test using mainly the numeric checking trick. 
Run it to verify everything works well after compiling the mex files.