%%
mex MaxPooling.cpp
%%
copyfile MaxPooling.* ./../