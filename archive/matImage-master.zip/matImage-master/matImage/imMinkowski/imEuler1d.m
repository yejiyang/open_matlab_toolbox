function [chi, labels] = imEuler1d(img, varargin)
% Compute Euler number of a binary 1D image
%
%   The function computes the Euler number, or Euler-Poincare
%   characteristic, of a binary 2D image. The result corresponds to the
%   number of connected components in the image.
%
%   CHI = imEuler1d(IMG);
%   return the Euler-Poincar� Characteristic, which is the number of
%   connected components.
%   IMG must be a binary image.
%
%   [CHI LABELS] = imEuler1d(LBL);
%   When LBL is a label image, returns the euler number of each label
%   different from 0. Returns also the set of unique values in LBL.
%
%   See also
%   imEuler2d, imEuler3d

% ------
% Author: David Legland
% e-mail: david.legland@grignon.inra.fr
% Created: 2010-01-15,    using Matlab 7.9.0.529 (R2009b)
% Copyright 2010 INRA - Cepia Software Platform.

%   HISTORY

% in case of a label image, return a vector with a set of results
if ~islogical(img)
    labels = unique(img);
    labels(labels==0) = [];
    chi = zeros(length(labels), 1);
    for i=1:length(labels)
        chi(i) = imEuler1d(img==labels(i), varargin{:});
    end
    return;
end

labels = 1;

% Compute Euler number by using graph formula: CHI = Nvertices - Nedges
chi = sum(img(:)) - sum(img(1:end-1) & img(2:end));

